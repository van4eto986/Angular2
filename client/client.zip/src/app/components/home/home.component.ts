import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import Data from '../../data/data.service';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'] 
})
export class HomeComponent implements OnInit {
  data: any = [];    

  constructor(private dataBase: Data, private router: Router){} 
  
  ngOnInit(){
    this.dataBase.getHomeData().then(data => {this.data = data.slice(0,1);});
 
  }  

  getAnimalId(animal){
    let animalId = animal.id;   
    this.router.navigateByUrl(`animals/details/${animalId}`);
  }

  animalInfoReceived(animalsInfo){    
    this.data = animalsInfo;
  }
}