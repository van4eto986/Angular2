import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import Data from '../../data/data.service';

@Component({
  selector: 'all',
  templateUrl: './all.component.html',
  styleUrls: ['./all.component.css'] 
})
export class AllComponent implements OnInit {
  data: any = [];    

  constructor(private dataBase: Data, private router: Router){} 
  
  ngOnInit(){
    this.dataBase.getAllData().then(data => {this.data = data;});
 
  }  

  getAnimalId(animal){
    let animalId = animal.id;   
    this.router.navigateByUrl(`animals/details/${animalId}`);
  }

  animalInfoReceived(animalsInfo){    
    this.data = animalsInfo;
  }

}