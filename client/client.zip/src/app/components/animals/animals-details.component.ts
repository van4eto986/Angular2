import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import Data from '../../data/data.service';
import { EventService } from '../../data/event.service';

@Component({
  selector: 'animal-details',
  templateUrl: './animals-details.component.html',
  styleUrls: ['./animals-details.component.css']

})
export class AnimalDetailsComponent implements OnInit {
  animalId: number;
  data = {name:'', id:'', category:'', image:''};
    
  constructor(
    private activatedRoute: ActivatedRoute,
    private dataBase: Data,
    private router: Router,
    private eventService: EventService
  ){}

  ngOnInit(){
    
    this.activatedRoute.params.subscribe((params: Params) => {
        this.animalId = params['id'];
        console.log(this.animalId);
      });

    this.dataBase
      .findAnimalById(this.animalId)
      .then(data => this.data = data);
  }

  delete(animalId){
    this.dataBase
    .deleteAnimal(animalId)
    .subscribe(res => {
      this.eventService.triggerNotificationFetched(res.message, res.success);
      this.router.navigateByUrl('/animals/all');
    });
  }
}