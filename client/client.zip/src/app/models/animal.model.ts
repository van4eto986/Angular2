export class Animal{
  constructor(
    public name: string = '',
    public age: number =0,
    public color: string = '',
    public type: string='Cat',
    public price: number = 0,
    public image: string = '',
    public breed: string = ''
  ){}
}