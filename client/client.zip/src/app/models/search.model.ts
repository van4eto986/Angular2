export class Search{
  constructor(
    searchParam: string = '' 
  ){}
}