export class AnimalReaction{
  constructor(
    public reaction: string = '',
    public comment: string = ''   
  ){}
}